//setTimeout(function() {
//    document.dispatchEvent(new CustomEvent('RW759_connectExtension', {
//        detail: thiswindow // Some variable from Gmail.
//    }));
//}, 0);